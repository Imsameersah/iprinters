/*disable copy paste*/



document.addEventListener('copy', (event) => {

   event.preventDefault();


});




/*disable right click:*/


document.addEventListener('contextmenu', (event) => {

   event.preventDefault();

   

   alert('Contact ADMIN for Permisssions.');

});

	
/*can visit 5 times only*/



//open with desktop


// Function to detect if the user is using a mobile device

function redirectToDesktop() {
    // Redirect to a page or show a message indicating access is restricted to desktop
    // You can display an alert or redirect to a specific page
    alert("Access to this content is available only on desktop devices.");
    // Alternatively, you can redirect to another page informing about desktop access
    // window.location.href = 'url-for-desktop-info-page';
}

function checkMobileDevice() {
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        // If the user is on a mobile device, redirect or show the message
        redirectToDesktop();
    }
}

// Check if the user is on a mobile device when the page loads
checkMobileDevice();


/*sessions */
// Function to redirect the user after a specified time (in milliseconds)
function redirectAfterTimeout() {
    // Redirect to a page or display a message indicating session timeout
    // You can display an alert or redirect to a specific page
    alert("Your session has expired. Please refresh the page to continue.");
    // Alternatively, you can redirect to another page or refresh the current page
    // window.location.href = 'url-for-refresh-page';
    // or
    // window.location.reload(true); // Reloads the current page
}

// Set timeout duration in milliseconds (1 minute and 30 seconds)
const timeoutDuration = 130000; // 90 seconds

// Function to start the timer
function startSessionTimer() {
    setTimeout(redirectAfterTimeout, timeoutDuration);
}

// Call the function to start the session timer when the page loads
startSessionTimer();

// Reset the timer if the user interacts with the page (e.g., mouse movement)
document.addEventListener('mousemove', function () {
    clearTimeout(startSessionTimer); // Clear previous timer
    startSessionTimer(); // Start a new timer when there's user activity
});


