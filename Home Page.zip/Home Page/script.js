// pop-up for the login button
function openPopup() {
  document.getElementById('popup').style.display = 'block';
}

function closePopup() {
  document.getElementById('popup').style.display = 'none';
}

  
// disable right click

// document.addEventListener('contextmenu', function(e) {
//     e.preventDefault();
//   });



